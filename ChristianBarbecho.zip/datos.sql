INSERT INTO `examen_bda`.`producto` (`codigo`, `cantidad`, `descripcion`, `precio`) VALUES ('1', '10', 'galletas', '5.20');
INSERT INTO `examen_bda`.`producto` (`codigo`, `cantidad`, `descripcion`, `precio`) VALUES ('2', '410', 'jabon', '1.10');
INSERT INTO `examen_bda`.`producto` (`codigo`, `cantidad`, `descripcion`, `precio`) VALUES ('3', '40', 'arroz', '45.50');
